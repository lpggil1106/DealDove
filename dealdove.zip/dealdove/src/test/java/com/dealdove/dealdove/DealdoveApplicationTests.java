package com.dealdove.dealdove;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealdoveApplicationTests {

	@Test
	void contextLoads() {
	}

}
